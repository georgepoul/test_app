create
    definer = root@localhost procedure add1(IN id4 int, IN quantity1 int, IN name1 varchar(20))
begin

    declare out1 boolean default false;
    declare continue handler for 1264
        set out1 = true;

 start transaction;

    insert into orders(order_id, quantity, product_name)
        values (id4, quantity1, name1);

    update products set product_stoke = product_stoke - quantity1
        where product_name = name1;

 if(out1)then
     rollback ;
 else
     commit ;

 end if;


end;

